
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Angel
 */
public class HojaTrabajo1 {
    static int cupoMaximo      = 15;
    static String[] secciones  = {"A","B"};
    static int[] cuposOcupados = {0,0};
    
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        String str="";
        while(!str.equals("Salir")){
            if(cuposOcupados[0]==15&&cuposOcupados[1]==15){
                System.out.println("Ambas secciones de IPC1 están llenas. Favor intentar abrir una nueva sección.");
                System.exit(0);
            }
            else{
                System.out.print("Seleccione Sección de IPC1 a asignarse (A o B o Salir): ");
                str = in.nextLine();
                if(str.equals("A")){
                    if(cuposOcupados[0]<=14){
                        cuposOcupados[0]=cuposOcupados[0]+1;
                        System.out.println("Asignado a sección A. Número de cupos ocupados: "+cuposOcupados[0]);
                    }
                    else{
                        System.out.println("Cupos de sección A llenos. Intentar asignarse a otra sección.");
                    }
                }
                else if(str.equals("B")){
                    if(cuposOcupados[1]<=14){
                        cuposOcupados[1]=cuposOcupados[1]+1;
                        System.out.println("Asignado a sección B. Número de cupos ocupados: "+cuposOcupados[1]);
                    }
                    else{
                        System.out.println("Cupos de sección B llenos. Intentar asignarse a otra sección.");
                    }
                }
                else{
                    System.out.println("Sección inválida. Debe seleccionar sección A o B para asignarse.");
                }
            }
        }
 
    }
}
